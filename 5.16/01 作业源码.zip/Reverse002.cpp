// Reverse002.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <windows.h>
#pragma comment(lib,"user32")
//h123jj321h
#define AfxMessageBox(s)  ::MessageBox(NULL,_T(s),_T("��ʾ"),MB_OK);  system("pause");
// 1sh6gr6ky6kw6hdq
int _tmain(int argc, _TCHAR* argv[])
{
    char szName[120];
    printf("please input Id: ");
    scanf_s("%s", szName, 120);

    if (szName[0] == '3')
    {
        AfxMessageBox("����");
        return -1;
    }
    else if (szName[0] != '1')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[1] == '1')
    {
        AfxMessageBox("����");
        return -1;
    }
    else if (szName[1] != 's')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[2] == '9')
    {
        AfxMessageBox("����");
        return -1;
    }
    else if (szName[2] != 'h')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[3] == '4')
    {
        AfxMessageBox("����");
        return -1;
    }
    else if (szName[3] != '6')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[4] == '8')
    {
        AfxMessageBox("����");
        return -1;
    }
    else if (szName[4] != 'g')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[5] == '2')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[5] != 'r')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[6] == 'A')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[6] != '6')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[7] == 'O')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[7] != 'k')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[8] == 'Y')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[8] != 'y')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[9] == 'x')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[9] != '6')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[10] == 'q')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[10] != 'k')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[11] == '6')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[11] != 'w')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[12] == 'h')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[12] != '6')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[13] == 'e')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[13] != 'h')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[14] == 'y')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
    if (szName[14] != 'd')
    {
        AfxMessageBox("����");
        return -1;
    }

    if (szName[15] == 'w')
    {
        AfxMessageBox("����");

        return -1;
    }
    else
    if (szName[15] != 'q')
    {
        AfxMessageBox("����"); 
        
        return -1;
    }
    else
       AfxMessageBox("�ɹ���");

    return 0;
}
