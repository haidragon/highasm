// Reverse001.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

// ���룺2s83gr3ky3kw3hdq
#include "stdafx.h"
#include <windows.h>
#pragma comment(lib,"user32")

#define AfxMessageBox(s)  ::MessageBox(NULL,_T(s),_T("��ʾ"),MB_OK);  system("pause");

int _tmain(int argc, _TCHAR* argv[])
{
    // ȫ�ֱ���
    char szName[120];
    printf("please input Id: ");
    scanf_s("%s", szName, 120);

    if (szName[0] != '2')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[1] != 's')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[2] != '8')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[3] != '3')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[4] != 'g')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[5] != 'r')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[6] != '3')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[7] != 'k')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[8] != 'y')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[9] != '3')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[10] != 'k')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[11] != 'w')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[12] != '3')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[13] != 'h')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[14] != 'd')
    {
        AfxMessageBox("����");
        return -1;
    }
    if (szName[15] != 'q')
    {
        AfxMessageBox("����");
        return -1;
    }
    else
        AfxMessageBox("�ɹ���");

    return 0;
}