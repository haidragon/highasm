#include "stdafx.h"
#include <windows.h>
// ȫ�ֱ���
char g_szId[120] = { " i love this game\n\n" };
#pragma comment(lib,"user32.lib")

int _tmain(int argc, _TCHAR* argv[])
{
    // �ֲ�����
    char szBuf[120];
    printf("please input password: ");
    scanf_s("%s", szBuf, 120);

    char* p = *(char**)((int)__iob_func()+8);
    if (strcmp(p, g_szId) == 0)
    {
        printf("It's Right , you are clever!..\n");
    }
    else
    {
        printf("It's Err , please Retry..\n");
    }
    system("pause");

    return 0;
}